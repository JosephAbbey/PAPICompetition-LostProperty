export const PHOTO_API = "/photo?id=";
export const url = new URL(window.location);